<?php
include 'components/header.php';
include 'components/nav/mainnav.php';
?>
 

<div class="row text-center mt-50 mb-50">
    <div class="offset-md-4 col-md-4">
        <div class="medica-appointment-card wow fadeInUp" data-wow-delay="0.6s" style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInUp;">
            <h5>Sign In Here</h5>
            <form action="data/u_face.php" method="post">
                <div class="form-group">
                    <input type="text" class="form-control text-white" name="username"  placeholder="Username">
                </div>
                <div class="form-group">
                    <input type="password" class="form-control" name="password" placeholder="Password">
                </div>
                <button type="submit" class="btn medica-btn mt-15" name="submit" value="log">Login Now</button>
            </form>
        </div>

    </div>
</div>



<?php
include 'components/footer.php';
?>
