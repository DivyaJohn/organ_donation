<?php
include 'components/header.php';
include 'components/nav/mainnav.php';
?>

<!-- page contents -->

<div class="height-800 bg-img" style="background-image: url(theme/img/bg-img/banner3.jpg);">
    <div class="container h-100">
        <div class="row h-100 align-items-center">
            <div class="col-12">
               <!-- <div class="display-1">
                    <h2 class="display-3 " data-animation="fadeInUp" data-delay="100ms">We provide top <br>medical services</h2>
                </div>-->
            </div>
        </div>
    </div>
</div>-->
<!--  <section class="hero-area">
//owl carousel     
<div class="hero-slides">
 Single Hero Slide 
<div class="single-hero-slide height-800 bg-img" style="background-image: url(theme/img/bg-img/banner3.jpg);">
    <div class="container h-100">
        <div class="row h-100 align-items-center">
            <div class="col-12">
                <div class="hero-slides-content">
                    <h2 data-animation="fadeInUp" data-delay="100ms">We provide top <br>medical services</h2>
                </div>
            </div>
        </div>
    </div>
</div>
 Single Hero Slide 
<div class="single-hero-slide height-800 bg-img" style="background-image: url(theme/img/bg-img/banner3.jpg);">
    <div class="container h-100">
        <div class="row h-100 align-items-center">
            <div class="col-12">
                <div class="hero-slides-content">
                    <h2 data-animation="fadeInUp" data-delay="100ms">We provide top <br>medical services</h2>
                </div>
            </div>
        </div>
    </div>
</div>
 Single Hero Slide 
<div class="single-hero-slide height-800 bg-img" style="background-image: url(theme/img/bg-img/banner3.jpg);">
    <div class="container h-100">
        <div class="row h-100 align-items-center">
            <div class="col-12">
                <div class="hero-slides-content">
                    <h2 data-animation="fadeInUp" data-delay="100ms">We provide top <br>medical services</h2>
                </div>
            </div>
        </div>
    </div>
</div>
</div>
</section>-->





<?php
include 'components/footer.php';
?>

