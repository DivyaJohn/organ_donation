<?php
//sessions are always include atmost top

include 'data/sessions.php';
if(!getSession('userid')){
    header('location:index.php');
}

include 'components/header.php';
include 'components/nav/admin_nav.php'
?>
 <!-- page contents -->
 
<div class="row text-center mt-50 mb-50">
    <div class="offset-md-4 col-md-4">
        <!--user contents-->
        
        
        <!--hello-->
    </div>
</div>
 

<?php
include 'components/footer.php';   
?>







