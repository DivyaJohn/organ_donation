<?php
include 'components/header.php';
include 'components/nav/mainnav.php';
?>

<div class="row text-center mt-50 mb-50">
    <div class="offset-md-4 col-md-4">
        <div class="medica-appointment-card wow fadeInUp" data-wow-delay="0.6s" style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInUp;">
            <h5>Register Now!</h5>
            <form action="data/u_face.php" method="post">
                <div class="form-group">
                    <select class="custom-select " name="bg">
                        <option selected>Selct Blood Group</option>
                        <option value="A+">A+</option>
                        <option value="A-">A-</option>
                        <option value="B+">B+</option>
                        <option value="B-">B-</option>
                        <option value="O+">O+</option>
                        <option value="O-">O-</option>
                        <option value="AB+">AB+</option>
                        <option value="AB-">AB-</option>
                    </select>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control text-white " name="height" required="height"  placeholder="Height">
                </div>
                <div class="form-group">
                    <input type="text" class="form-control text-white " name="weight" required="weight" placeholder="Weight">
                </div>
                <button type="submit" class="btn medica-btn mt-15 text-white" name="submit" value="u_regist2" onclick="alert('REGISTER SUCCESSFUL!')">Final submit</button>
            </form>
        </div>

    </div>
</div>




<?php
include 'components/footer.php';
?>


