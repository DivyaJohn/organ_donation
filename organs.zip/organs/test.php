<?php

include 'data/sessions.php';

print_r(getSession('last_id'));

print_r($_SESSION);
echo 'session array';

delSession('last_id');

print_r($_SESSION);
echo 'session array after delete';

$_SESSION['divya'] = 'beauty';


print_r($_SESSION);
echo 'session array after divya';

//ini //

$array['ind'] = 100000000000000;
echo $array['ind']; //oru normal array