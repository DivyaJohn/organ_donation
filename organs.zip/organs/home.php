<?php

include '../components/header.php';
//NAVBAR
include '../components/nav/user_nav.php';
?>

 <!-- page contents -->
 
 

<?php

echo getcwd();
//echo dirname($path)
echo realpath('home.php');
include '../components/footer.php';   
?>

