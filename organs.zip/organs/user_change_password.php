<?php
include 'data/dbconnection.php';
include 'data/sessions.php';
$userid = getSession('$userid');
if (!'userid') {
    header('location:index.php');
}
$id = $_SESSION['userid'];

include 'components/header.php';
include 'components/nav/user_nav.php'
?>



<div class="row text-center mt-50 mb-50">
    <div class="offset-md-4 col-md-4">
        <div class="medica-appointment-card wow fadeInUp" data-wow-delay="0.6s" style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInUp;">
            <h5>Change your Password Here</h5>
            <form method="post">
                <div class="form-group">
                    <label>Current Password</label>
                    <input type="text" class="form-control text-white" name="password1"  placeholder="password">
                </div>
                <div class="form-group">
                    <label>New Password</label>
                    <input type="password" class="form-control" name="password2" placeholder="Password">
                </div>
                <div class="form-group">
                    <label>Confirm Password</label>
                    <input type="password" class="form-control" name="password3" placeholder="Password">
                </div>
                <button type="submit" class="btn medica-btn mt-15" name="submit">Save</button>
            </form>
        </div>

    </div>
</div>
<?php
if (isset($_POST["submit"])) {
    $cp = $_POST["password1"];
    $np = $_POST["password1"];
    $cnp = $_POST["password1"];
    $q="select * from login where uid='$id'";
    $data=mysqli_query($con,$q) or die(mysqli_error($con));
    if($r=mysqli_fetch_array($data))
	{
		if($np==$cnp)
		{
			$q="update login set password='$np' where uid='$id'";
			$data=mysqli_query($con,$q) or die( mysqli_error($con));
			?>
			<script>
			alert("CHANGED");
			</script>
			<?php
		}
		else
		{
			?>
			<script>
			alert("PASSWORD NOT MATCHING");
			</script>
			<?php
		}
	}
	else
	{
		?>
		<script>
		alert("INCORRECT PASSWORD");
		</script>
		<?php
	}
}
?>


<?php
include 'components/footer.php';
?>