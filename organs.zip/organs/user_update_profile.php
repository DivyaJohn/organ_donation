<?php
include 'data/dbconnection.php';
include 'data/sessions.php';
$userid = getSession('$userid');
if (!'userid') {
    header('location:index.php');
}
$id = $_SESSION['userid'];

include 'components/header.php';
include 'components/nav/user_nav.php'
?>

<div class="row text-center mt-50 mb-50">
    <div class="offset-md-4 col-md-4">

        <?php
        // $id = $userid;
        $q = "select * from doner where id='$id'";
        $data = mysqli_query($con, $q) or die(mysqli_error($con));
        while ($r = mysqli_fetch_array($data)) {
            ?>
            <div class="medica-appointment-card wow fadeInUp" data-wow-delay="0.6s" style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInUp;">
                <h5>Register Now!</h5>
                <form method="post" id="regForm">
                    <div class="form-group">
                        <input type="text" class="form-control text-white validate" name="name" value="<?php echo $r[1];?>" id="ename" onchange="lname();" placeholder="Name">
                    </div>
                    <div class="row mb-4">
                        <div class="col-md-12">
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="gender"  value="male" checked="male">
                                <label class="form-check-label text-white">Male</label>
                            </div>
                            <div class="form-check form-check-inline">
                                <input class="form-check-input" type="radio" name="gender" value="female">
                                <label class="form-check-label text-white">female</label>
                            </div>
                        </div>
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control text-white validate" name="dob" value="1970-01-01" value="<?php echo $r[3];?>" id="dob" placeholder="Date of Birth" required  readonly >
                    </div>
                    <div class="form-group">
                        <input type="text" class="form-control text-white validate" name="location" value="<?php echo $r[4];?>" id="place" onchange="pl_c();" placeholder="Location"equired="">
                    </div>
                    <div class="form-group">
                        <input type="tel" class="form-control text-white validate" name="number" value="<?php echo $r[5];?>" id="mobile" onchange="mob();" placeholder="Mobile">
                    </div>
                    <div class="form-group">
                        <input type="email" class="form-control text-white validate" name="email" value="<?php echo $r[6];?>" id="email" onchange="checkEmail();"  placeholder="E-mail">
                    </div>
                    <input hidden="" name="_type" value="u_regist">
                    <button type="submit" class="btn medica-btn mt-15" name="submit">Update Now!</button>                
                </form>
            </div>
            <?php
        }
        ?>



    </div>
</div>
<?php
if(isset($_POST["submit"]))
{
    $q="update doner set name='".$_POST["name"]."',sex='".$_POST["gender"]."',dob='".$_POST["dob"]."',location='".$_POST["location"]."',location='".$_POST["location"]."',email='".$_POST["email"]."' where id='$id'";
    $data=mysqli_query($con,$q) or die( mysqli_error($con));
	if(mysqli_affected_rows($con)>0)
	{
		?>
		<script>
			alert("UPDATED");
				window.location.href="view.php";
			</script>
		<?php
	}
}
?>

<?php
include 'components/footer.php';
?>
