<?php
include 'data/dbconnection.php';
include 'data/sessions.php';
$userid = getSession('$userid');
if (!'userid') {
    header('location:index.php');
}
$id=$_SESSION['userid'];

include 'components/header.php';
include 'components/nav/user_nav.php'
?>

<div class="row text-center mt-50 mb-50">
    <div class="offset-md-4 col-md-4">
        <!--user contents-->
        <?php
       // $id = $userid;
        $q = "select * from doner where id='$id'";
        $data = mysqli_query($con, $q) or die(mysqli_error($con));
        while ($r = mysqli_fetch_array($data)) {
            ?>
            <form method="post">
                <table>
                    <tr>
                        <td>Name:<?php echo $r[1]; ?></td>
                    </tr>
                    <tr>
                        <td>Gender:<?php echo $r[2]; ?></td>
                    </tr>
                    <tr>
                        <td>Date of Birth:<?php echo $r[3]; ?></td>
                    </tr>
                    <tr>
                        <td>Location:<?php echo $r[4]; ?></td>
                    </tr>
                    <tr>
                        <td>Mobile:<?php echo $r[5]; ?></td>
                    </tr>
                    <tr>
                        <td>Email:<?php echo $r[6]; ?></td>
                    </tr>
                </table>
            </form>
            <?php
        }
        ?>

        <!--hello-->
    </div>
</div>



<?php
include 'components/footer.php';
?>


