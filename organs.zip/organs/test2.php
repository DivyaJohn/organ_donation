<?php

//pine session variables access cheyyan first
session_start(); //venam
//ketto? 
//mm

echo $_SESSION['divya'];
//nokkiye ithoru different page aannu
//but ivdem session kittum
//matte pagel set cheythe value aanu

echo $array['ind'];

