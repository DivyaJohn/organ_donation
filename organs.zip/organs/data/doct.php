<?php

//db connection
require 'dbconnection.php';
require 'sessions.php';

if (isset($_POST['submit'])) {

    ///functions for user
    function userregistration3($con) {
//        print_r($_POST);
        $name = $_POST["name"];
        $gender = $_POST["gender"];
        $hspname = $_POST["hspname"];
        $spltion = $_POST["Splon"];
        $regno = $_POST["regno"];
        $mobile = $_POST["number"];
        $email = $_POST["email"];
        $username = $_POST["username"];
        $password = $_POST["password"];

        $q = "insert into login values(NULL,'$username','$password','2')";
        //echo $q;
        if (mysqli_query($con, $q)) {

            $last_id = mysqli_insert_id($con);
            $q = "insert into doctor values('$last_id','$name','$gender','$hspname','$spltion','$regno','$mobile','$email')";
            //echo $q;
            if (mysqli_query($con, $q)) {
                
                setSession('userid', $last_id);
                header("location:../doctor_home.php");
            }
        }
        /* mysqli_query($con,$q) or die(mysqli_error($con));
          $last_id = mysqli_insert_id($con);
          $q="insert into login values($last_id,'".$_POST["txt8"]."','".$_POST["pswd"]."','2')";
          mysqli_query($con,$q) or die(mysqli_error($con));
          //header("location:health_details.php?id=$last_id");
          } */
    }

    //check requests
    $type = $_POST['submit'];
    switch ($type) {
        case 'u_regist3':
            userregistration3($con);
            break;
        default :
            echo 'error';
            break;
    }
}
?>