<?php
$con= mysqli_connect("localhost","root","","organ_donation");
?>