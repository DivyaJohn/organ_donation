<?php
session_start();

function setSession($index, $value){ //set session variable
    $_SESSION[$index] = $value;
}

function delSession($index){ //delete session
    unset($_SESSION[$index]);
}       

function getSession($index){ //read a session value
    if(isset($_SESSION[$index])){
        return $_SESSION[$index]; //value set cheythitt indel value return cheyyanm
    }
    return false; //allelu false return cheyyum
}         
?>