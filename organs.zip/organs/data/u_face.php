<?php

//db connection
require 'dbconnection.php';
require 'sessions.php';

if (isset($_POST['submit'])) {

    ///functions for user
    function userregistration($con) {
//        print_r($_POST);
        $name = $_POST["name"];
        $gender = $_POST["gender"];
        $dob = $_POST["dob"];
        $location = $_POST["location"];
        $mobile = $_POST["number"];
        $email = $_POST["email"];
        $username = $_POST["username"];
        $password = $_POST["password"];
        $q = "insert into login values(NULL,'$username','$password','1')";
        //echo $q;
        if (mysqli_query($con, $q)) {

            $last_id = mysqli_insert_id($con);
            $q = "insert into doner values('$last_id', '$name','$gender','$dob','$location','$mobile','$email')";
            if (mysqli_query($con, $q)) {
//                echo 'sucdcessu';
                setSession('last_id', $last_id);
                header("location:../user_registration2.php");
            }
        }
    }

    function userregistration2($con) {
        $bg = $_POST["bg"];
        $ht = $_POST["height"];
        $wt = $_POST["weight"];
        $id = getSession('last_id');
        $q = "insert into doner_health values('$id','$bg','$ht','$wt')";
        if (mysqli_query($con, $q)) {
            setSession('userid', $id);
            header("location:../userhome.php");
        } else {
            //----error
            echo 'err';
        }
    }

    function login($con) {
        //print_r($_POST);
        $username = $_POST["username"];
        $password = $_POST["password"];
        $sql = "select * from login where username='$username' and password='$password'";
        //echo $sql;
        $res = mysqli_query($con, $sql);
        //print_r($res);
        while ($fetch = mysqli_fetch_array($res)) {
            if ($fetch['roll'] == 0) {//ADMIN_PAGE
                $_SESSION['userid'] = $fetch['uid'];
                header("location:../admin_home.php");
            }

            if ($fetch['roll'] == 1) {//USER_PAGE
                $_SESSION['userid'] = $fetch['uid'];
                header("location:../userhome.php");
                
            }
            if ($fetch['roll'] == 2) {//DOCTOR_PAGE
                $_SESSION['userid'] = $fetch['uid'];
                header("location:../doctor_home.php");
            }   
        }
    }

    $type = $_POST['submit'];
    //check requests
    switch ($type) {
        case 'u_regist':

            userregistration($con);
            break;
        case 'u_regist2':
            userregistration2($con);
            break;
        case 'log':

            login($con);
            break;
        default :
            echo 'error';
            break;
    }
}
?>