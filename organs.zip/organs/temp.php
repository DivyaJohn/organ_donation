




<div class="medica-appointment-card wow fadeInUp" data-wow-delay="0.6s" style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInUp;">
                            <h5>Book an apppointment</h5>
                            <form action="#" method="post">
                                <div class="form-group">
                                    <input type="text" class="form-control text-white" name="name" id="name" placeholder="Name">
                                </div>
                                <div class="form-group">
                                    <input type="text" class="form-control" name="number" id="number" placeholder="Phone">
                                </div>
                                <div class="form-group">
                                    <input type="email" class="form-control" name="email" id="email" placeholder="E-mail">
                                </div>
                                <button type="submit" class="btn medica-btn mt-15">Make an Appointment</button>
                            </form>
                        </div>