<?php

include 'components/header.php';
//NAVBAR
include 'components/nav/mainnav.php';
?>

 <!-- page contents -->
 
 

<?php
include 'components/footer.php';   
?>

