<?php
include("dbconnection.php");
if(isset($_POST["submit"]))
{
       $id=$_GET['id'];
	$q="insert into doner_health values($id,'".$_POST["bg"]."','".$_POST["txt1"]."','".$_POST["txt2"]."')";
	mysqli_query($con,$q) or die(mysqli_error($con));
        $last_id = mysqli_insert_id($con);
       header("location:varification.php?id=$last_id");
}
?>
<html>
<head>
<script>
function check(x,type)
{
var res=0;
	if(window.XMLHttpRequest)
	{
		obj=new XMLHttpRequest();
	}
	else
	{
		obj=new ActiveXobject("microsoft.XMLHTTP");
	}
	
	obj.onreadystatechange=function()
	{
		if(obj.status==200 && obj.readyState==4)
		{
			var res=obj.responseText;
			if(res=="yes")
			{
			
	document.getElementById("btn").disabled="true";
	document.getElementById("err").innerHTML="<font color='red'>Already Exist</font>";
			}
			else
			{
				document.getElementById("btn").disabled="";
	document.getElementById("err").innerHTML="";

			}
		}
	}
	
		obj.open("GET","checkuname.php?uname="+x+"&type="+type,true);
	obj.send();
	
	

}
</script>
</head>
<body>
<form method="post" >
<table  align="center">
<tr height="70" width="50">
    <td>BLOOD GROUP</td><td><select name="bg">
            <option value="A+">A+</option>
            <option value="A-">A-</option>
            <option value="B+">B+</option>
            <option value="B">B-</option>
            <option value="O+">O+</option>
            <option value="O-">O-</option>
            <option value="AB+">AB+</option>
            <option value="AB-">AB-</option></select></td>
</tr>
<tr height="70" width="50">
    <td>HEIGHT</td><td><input type="text" name="txt1"/></td>
</tr>
<tr height="70" width="50">
    <td>WEIGHT</td><td><input type="text" name="txt2"/></td>
</tr><br><br><br>
<tr>
<td><input type="submit" name="submit" value="submit" id="btn" /></td>
</tr>
</table>
</form>
</body>
</html>
