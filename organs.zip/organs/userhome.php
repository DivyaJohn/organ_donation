<?php
//sessions are always include atmost top

include 'data/sessions.php';
$userid = getSession('userid');
if(!$userid){
    header('location:index.php');
}
include 'components/header.php';
include 'components/nav/user_nav.php'
?>
 <!-- page contents -->
 
       

 
 
 
<!--<div class="row text-center mt-50 mb-50">
    <div class="offset-md-4 col-md-4">-->
        <!--user contents-->
        <section class="hero-area">
                  <div class="single-hero-slide height-800 bg-img" style="background-image: url(theme/img/bg-img/hero2.jpg);">
                <div class="container h-100">
                    <div class="row h-100 align-items-center">
                        <div class="col-12">
                            <div class="hero-slides-content">
                                <h2 data-animation="fadeInUp" data-delay="100ms">We provide top <br>medical services</h2>
                                <div class="slide-btn-group mt-50" data-animation="fadeInUp" data-delay="700ms">
                                    <a href="index.php" class="btn medica-btn ml-2 btn-2">Make an Appoinment</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!--hello-->
    <!--</div>
</div>-->
 

<?php
include 'components/footer.php';   
?>

