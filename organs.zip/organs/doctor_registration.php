<?php
include 'components/header.php';
include 'components/nav/mainnav.php';
?>

<script src="js/validate.js"></script>
<script src="js/jquery-ui.js"></script>
<script>
    //var myInput = document.getElementById("password1");
    // function validate(){
    // if (document.getElementById("subdistrict").selectedIndex == 0){
    //alert("Select Subdistrict");
    //}
    //else {
    //  alert(document.getElementById("subdistrict").options[document.getElementById("subdistrict").selectedIndex].value);
    //}

    function mob()
    {
        var val = document.getElementById('mobile').value;
        if (!val.match(/^[7-9][0-9]{9,9}$/))
        {
            $("#mobile_l").html('Only Numbers are allowed and must contain 10 number..!').fadeIn().delay(3000).fadeOut();
            document.getElementById('mobile').value = "";
            mobile.focus();
            return false;
        }
        return true;
    }
    function pinc()
    {
        var val = document.getElementById('pincode').value;
        if (!val.match(/^[3-6][0-9]{5,5}$/))
        {
            $("#pin_l").html(' must contain 6 digits!').fadeIn().delay(3000).fadeOut();
            document.getElementById('pincode').value = "";
            pincode.focus();
            return false;
        }
        return true;
    }

    function checkEmail()
    {

        var email = document.getElementById('email');
        var filter = /^([a-zA-Z0-9_\.\-])+\@(([a-zA-Z0-9\-])+\.)+([a-zA-Z0-9]{2,4})+$/;

        if (!filter.test(email.value)) {
            email.value = "";

            alert('Please provide a valid email address');
            email.focus();
            // document.getElementById("email").addEventListener("focusin",checkemail());
            return false;
        }
    }
    $(function () {
        $('#dob').datepicker({
            dateFormat: 'yy/mm/dd',
            yearRange: '1960:2015',
            changeMonth: true,
            changeYear: true,
            minDate: '10/26/1960',
        });
    });
        function user()
        {
            var val = document.getElementById('usr').value;
            if (!val.match(/^[A-Za-z][A-Za-z""]{3,}$/))
            {
                $("#uname_l").html(' Only Alphabets allowed with minimum 3 characters without space!').fadeIn().delay(3000).fadeOut();
                document.getElementById('usr').value = "";
                usr.focus();

                return true;
            }
        }
        function lname()
        {
            var val = document.getElementById('ename').value;
            if (!val.match(/^[A-Za-z][A-Za-z" "]{3,}$/))
            {
                $("#name_l").html('Min. 3 and Only Alphabets allowed..!').fadeIn().delay(3000).fadeOut();
                document.getElementById('ename').value = "";
                ename.focus();

                return true;
            }
        }
        function h_name()
        {
            var val = document.getElementById('hname').value;
            if (!val.match(/^[A-Za-z][A-Za-z""]{3,}$/))
            {
                $("#hname_l").html('Min. 3 and Only Alphabets allowed..!').fadeIn().delay(3000).fadeOut();
                document.getElementById('hname').value = "";
                hname.focus();

                return true;
            }
        }
        function pl_c()
        {
            var val = document.getElementById('place').value;
            if (!val.match(/^[A-Za-z][A-Za-z" "]{3,}$/))
            {
                $("#pname_l").html(' Only Alphabets allowed..!').fadeIn().delay(3000).fadeOut();
                document.getElementById('place').value = "";
                place.focus();

                return true;
            }
        }
        function CheckPassword()
	{


		var p=document.getElementById('password').value;
		var passw=  /^[A-Za-z]\w{7,14}$/;
                var error = "";
                 var illegalChars = /[\W_]/; // allow only letters and numbers
 
                     if (p == "") {
                                $("#pswrd_l").html('Please provide a password').fadeIn().delay(3000).fadeOut();
                                password.focus();
                                 
                                    return false;
                        }
                        else if ((p.length < 7) || (p.value.length > 15)&& (p.search(/[a-zA-Z]+/)==-1) || (p.search(/[0-9]+/)==-1)) {
        $("#pswrd_l").html('Please provide a password with atleast 8 characters and digits').fadeIn().delay(3000).fadeOut();
        
        
         password.value="";
        password.focus();
        return false;
 
    } else if ( (p.search(/[a-zA-Z]+/)==-1) || (p.search(/[0-9]+/)==-1) ) {
        $("#pswrd_l").html('Please provide a password with atleast 1 numeric digit').fadeIn().delay(3000).fadeOut();
                 password.value="";
        password.focus();
        
        return false;
 
    } else {
        p.style.background = 'White';
    }
   return true;
}


        function Cnfrmpassword()
        {
            if (document.getElementById("password").value == document.getElementById("passwrd").value)
            {
                return true;
            } else
            {
                alert("***Password Mismatch***");
                passwrd.value = "";
                passwrd.focus();

                return false;
            }
        }







</script> 
  

<div class="row text-center mt-50 mb-50">
    <div class="offset-md-4 col-md-4">
        <div class="medica-appointment-card wow fadeInUp" data-wow-delay="0.6s" style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInUp;">
            <h5>Register Now!</h5>
            <form action="data/doct.php" method="post">
                <div class="form-group">
                    <input type="text" class="form-control text-white validate " name="name" id="ename" onchange="lname();" placeholder="Name" required>
                    <label style="display:none ; color:white"  id="name_l"></label>
                </div>
                <div class="row mb-4">
                    <div class="col-md-12">
                        <div class="form-check form-check-inline ">
                            <input class="form-check-input" type="radio" name="gender" value="male" checked="male" >
                            <label class="form-check-label text-white">Male</label>
                        </div>
                        <div class="form-check form-check-inline ">
                            <input class="form-check-input" type="radio" name="gender" value="female">
                            <label class="form-check-label text-white" >female</label>
                        </div>

                    </div>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control text-white validate" name="hspname"  placeholder="Hospital Name" required>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control text-white  validate" name="Splon"  placeholder="Specialization" required>
                </div>

                
                <div class="form-group">
                    <input type="text" class="form-control text-white " name="regno"  placeholder="Register Number" required>
                </div>
                <div class="form-group">
                    <input type="tel" class="form-control text-white validate" name="number" id="mob" onchange="mobile();" placeholder="Mobile" required>
                    <label style="display:none ; color:white"  id="mobile_l"></label>
                </div>
                <div class="form-group">
                    <input type="email" class="form-control text-white validate" name="email" id="email" onchange="checkEmail();" placeholder="E-mail" required>
                    <label style="display:none ; color:white"  id="pswrd_l"></label>
                </div>
                <div class="form-group">
                    <input type="text" class="form-control text-white validate" name="username" id="usr" onchange="user();" placeholder="Username" required>
                    <label style="display:none ; color:white"  id="uname_l"></label>
                </div>
                <div class="form-group">
                    <input type="password" class="form-control text-white validate" name="password" id="password" onchange="CheckPassword();" placeholder="Password" required>
                    <label style="display:none ; color:white"  id="pswrd_l"></label>
                </div>
                <input hidden="" name="_type" value="u_regist">
                
                <button type="submit" class="btn medica-btn mt-15 text-white" name="submit" value="u_regist3" onclick="alert('REGISTER SUCCESSFUL!')">Register</button>                
            </form>
        </div>


    </div> 
</div>



<?php
include 'components/footer.php';
?>


