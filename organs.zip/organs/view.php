<?php
include 'data/dbconnection.php';
include 'data/sessions.php';
$userid = getSession('$userid');
if (!'userid') {
    header('location:index.php');
}
$id = $_SESSION['userid'];

include 'components/header.php';
include 'components/nav/user_nav.php'
?>



<div class="row text-center mt-50 mb-50">
    <div class="offset-md-4 col-md-4">

        <?php
        // $id = $userid;
        $q = "select * from doner where id='$id'";
        $data = mysqli_query($con, $q) or die(mysqli_error($con));
        while ($r = mysqli_fetch_array($data)) {
            ?>
            <div class="medica-appointment-card wow fadeInUp" data-wow-delay="0.6s" style="visibility: visible; animation-delay: 0.6s; animation-name: fadeInUp;">
                <h5>My Profile</h5>
                <form method="post" id="regForm">
                    <div class="form-group">
                        Name: <div class="form-control text-white validate"><?php echo $r[1]; ?>
                        </div></div>
                    <div class="form-group">
                        Gender:<div class="form-control text-white validate"><?php echo $r[2]; ?>
                        </div></div>
                    <div class="form-group">
                        Date of Birth:<div class="form-control text-white validate"><?php echo $r[3]; ?>
                        </div></div>
                    <div class="form-group">
                        Location:<div class="form-control text-white validate"><?php echo $r[4]; ?>
                        </div></div>
                    <div class="form-group">
                        Mobile:<div class="form-control text-white validate"><?php echo $r[5]; ?>
                        </div></div>
                    <div class="form-group">
                        Email:<div class="form-control text-white validate"><?php echo $r[6]; ?>
                        </div></div>
                    <div class="form-group text-white">
                        <a href="user_update_profile.php?id=<?php echo $r['id'];?>">Update</a>
                        </div></div>
                </form>
            </div>
            <?php
        }
        ?>



    </div>
</div>

<?php
include 'components/footer.php';
?>