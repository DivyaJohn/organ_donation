<?php
//sessions are always include atmost top
include 'data/dbconnection.php';
include 'data/sessions.php';
$userid = getSession('$userid');
if (!'userid') {
    header('location:index.php');
}
$id=$_SESSION['userid'];   

include 'components/header.php';
include 'components/nav/doct_nav.php'
?>

<!--
 <!-- page contents -->
<!--<div class="row text-center mt-50 mb-50">
    <div class="offset-md-4 col-md-4">-->
        <!--user contents
  <section class="hero-area">
                  <div class="single-hero-slide height-800 bg-img" style="background-image: url(theme/img/bg-img/hero6.jpg);">
                <div class="container h-100">
                    <div class="row h-100 align-items-center">
                        <div class="col-12">
                            <div class="hero-slides-content">
                                <h2 data-animation="fadeInUp" data-delay="100ms">WELCOME TO<br>DOCTORS PANNEL</h2>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </section>
        <!--hello
    <!--</div>
</div>-->

<form>
      <table border="1">
          
        <?php
        $query1="SELECT name,hosp_name FROM doctor WHERE doct_id='$id'";
               $s=mysqli_query($con,$query1);
      
        while ($row=mysqli_fetch_array($s))
	 {
          ?>
          <tr>
		 <!-- <div class="col-sm-5 col-xs-6 tital " >First Name:</div><div class="fill "  type="label"  value="/  >Prasad</div>
     <div class="clearfix"></div>
<div class="bot-border"></div>-->
                 
                 
    Name:<input class="fill" type="label"  value="<?php echo $row['name'];  ?>"/></tr><br>
            
	<tr>Email<input class="fill" type="text"  value="<?php echo $row['hosp_name'];  ?>"/></tr><br>
		  
          <?php
        }
        ?>
      </table>
    </form>
	
	


 

<?php
include 'components/footer.php';   
?>







